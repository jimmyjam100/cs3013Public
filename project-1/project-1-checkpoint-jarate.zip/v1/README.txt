To compile the program, run

$ gcc main.c -o mc1

Then you may need to give it permission to run as an executable with

$ chmod +x mc1

Then finally you can run

$ ./mc1

