There are two problems for project-3

Enclosed in the problem1 directory are the files for pirates versus ninjas.

Enclosed in the problem2 directory are the files for the intersection simulation program.

